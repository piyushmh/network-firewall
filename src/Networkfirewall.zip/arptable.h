/*
 * arptable.h
 *
 *  Created on: 06-Nov-2013
 *      Author: piyush
 */

#ifndef ARPTABLE_H_
#define ARPTABLE_H_

#include "network_interface.h"

void arp_table_initialize();
u_char* find_macaddr_network_interface();
void find_macaddr_ip();

#endif /* ARPTABLE_H_ */
