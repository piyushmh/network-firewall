/*
 * network_interface.h
 *
 *  Created on: 06-Nov-2013
 *      Author: piyush
 */

#ifndef NETWORK_INTERFACE_H_
#define NETWORK_INTERFACE_H_

#include <netinet/if_ether.h>
#include <pcap.h>

struct network_interface{
	char devname[20];
	bpf_u_int32 mask;           /* Our netmask */
	bpf_u_int32 net;        /* Our IP */
	pcap_t *handle;
};


struct pcap_handler_argument{
	struct network_interface source;
	struct network_interface dest;
	//pcap_t *desthandle;
};

#endif /* NETWORK_INTERFACE_H_ */
