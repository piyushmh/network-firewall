#include "firewall_main.h"
#include "packet_reader.h"
#include <libnet.h>
#include "apply_rule.h"

int main(int argc, char** argv){
 	
    int c;
    char *sourcedev = NULL;
    char *destdev = NULL;
    while((c = getopt(argc, argv, "s:d:")) != EOF){
    	switch (c) {
            case 's' :
                sourcedev = optarg;
                break;
            case 'd' :
                destdev = optarg;
                break;
            default:
                printf("%s\n", "Enter correct arguments");
                exit(3);
        }
    }

    if(destdev == NULL){
        printf("%s\n", "Enter correct arguments1");
        exit(3);
    }

    if(sourcedev == NULL){
        printf("%s\n", "Enter correct arguments2");
        exit(3);
    }

    initialize_rules(); //read rules of files and initialize system
    read_packets(sourcedev, destdev);
    return(0);
}
