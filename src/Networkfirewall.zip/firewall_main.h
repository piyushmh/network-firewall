#ifndef FIREWALL_MAIN_H
#define FIREWALL_MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include <stdlib.h>
#include <assert.h>
#include <memory.h>
#include <time.h>
#include <signal.h>

//#define DEBUG  //un comment this for debugging statements


#endif /* FIREWALL_MAIN_H*/
